﻿=====================
    SD2DExtender 0.1 (29-03-2015)
		By Domonix
=====================


!! IMPORTANT !!
You may have issues if you are not using vanilla assets.
When you first compile in the mod launcher, it automatically backs up your Configs and Assembly-CSharp.dll
These files are used as the base when generating the final assets used in-game.
!! IMPORTANT !!


---------------------
ABOUT
---------------------

SD2DX is a mod manager and mod loader for the game "7 Days To Die"

No more sharing giant .assets files - yay!


---------------------
HOW DOES IT WORK?
---------------------

The ModLoader modifies your Assembly-CSharp.dll (The games code) to provide
a way to load custom assets (icons, models, etc).


The ModManager loads all the mods in your Mods folder and generates:

Standard configs:
 - items.xml
 - recipes.xml
 (MORE SOON!)

Custom texture atlas (loaded at runtime)
 - CompiledMods/Icons.png
 - CompiledMods/Icons.xml

And a English.txt file that is also patched in at runtime
 - CompiledMods/English.txt


In some cases the mod compiler uses the load order so that assets can be overridden


---------------------
GETTING STARTED
---------------------

EXAMPLE MOD:
 - https://mega.co.nz/#!ZIglXAYR!oF7tMMMl5fMOfcewIkueBraQgqsPEQ1kxQcc_9cuolQ
 - Contains a fully functional weapon mod to use as a base

EXAMPLE Unity weapon asset, ready for export
 - https://mega.co.nz/#!gZBVUbgC!WPa7aRfFqmgOuGLGFiBpC6c5bU5Oy9Ay2Mq9nftH1-0
 - Right click on the Prefabs/ConfederatePistolPrefab
   and select "Build Asset Bundle From Selection - Track Dependencies"


1)
Create a Mods folder in your 7 Days To Die directory.
e.g: "C:\Program Files (x86)\Steam\SteamApps\common\7 Days To Die\Mods"

2)
Place mods in your Mods folder.
The mod format is as follows:

Mods/YourModName
 - Icons		(optional)
 - Items		(optional)
 - Recipes		(optional)
 - Resources	(optional)
 - Text			(optional)
 mod.xml		(required)



---------------------
NOTES
---------------------

== ASSET LOADING ==

The asset loading hooks redirect paths that start with '#' to asset bundles

The format is
#MyBundle?MyAsset

An example of this can be seen in the mod linked above.

From the confPistol.xml

	mesh_file="#ConfederatePistol?ConfederatePistolPrefab"

This refers to prefab "ConfederatePistolPrefab" in the bundle "Resources/ConfederatePistol.unity3d"


== AUTOMATIC ITEM ID ASSIGNMENT ==

The ModManager automatically assigns item ids to your items to make it play friendly with other mods
Obviously this can cause problems with save games and multiplayer if your mod load order changes.

You can disable this in "SD2DXLauncher.ini"
Just set "autoAssignItemIds" to "false"

There are future plans to work on allocating address spaces to mods in a sane way


---------------------
LINKS
---------------------

Domonix on the 7 Days To Die forum
 - https://7daystodie.com/forums/member.php?106432-Domonix